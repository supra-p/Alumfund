package com.ooad.alumfund;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlumfundApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlumfundApplication.class, args);
	}
 
} 
	