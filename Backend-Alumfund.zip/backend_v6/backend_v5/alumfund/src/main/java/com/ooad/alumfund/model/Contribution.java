package com.ooad.alumfund.model;

import lombok.Data;

@Data
public class Contribution {
	
	private long index;
	private long amount;

}
