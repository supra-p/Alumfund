package com.ooad.alumfund.model;

public interface BioData {
		String putInformation();
}
