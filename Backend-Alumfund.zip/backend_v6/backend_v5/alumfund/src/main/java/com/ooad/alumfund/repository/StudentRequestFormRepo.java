//package com.ooad.alumfund.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.ooad.alumfund.model.StudentRequestForm;
//
//public interface StudentRequestFormRepo extends JpaRepository<StudentRequestForm, String>{
//
//}
