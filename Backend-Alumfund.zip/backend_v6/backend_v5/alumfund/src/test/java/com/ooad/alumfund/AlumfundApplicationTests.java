package com.ooad.alumfund;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlumfundApplicationTests {

	@Test
	void contextLoads() {
	}

}
